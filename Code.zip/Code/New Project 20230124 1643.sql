-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.30-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema tendermgmt
--

CREATE DATABASE IF NOT EXISTS tendermgmt;
USE tendermgmt;

--
-- Definition of table `bidder`
--

DROP TABLE IF EXISTS `bidder`;
CREATE TABLE `bidder` (
  `bid` varchar(15) NOT NULL,
  `vid` varchar(15) DEFAULT NULL,
  `tid` varchar(15) DEFAULT NULL,
  `bidamount` int(11) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidder`
--

/*!40000 ALTER TABLE `bidder` DISABLE KEYS */;
INSERT INTO `bidder` (`bid`,`vid`,`tid`,`bidamount`,`deadline`,`status`) VALUES 
 ('B20221008123938','V20221003113600','T20221007045336',400000,'2022-10-09','Rejected'),
 ('B20221008124008','V20221004022217','T20221007045336',330000,'2022-10-09','Accepted'),
 ('B20221229033050','V20221229031430','T20221229032549',320000,'2022-12-16','Pending'),
 ('B20221229033426','V20221229031548','T20221229032549',310000,'2022-12-16','Accepted');
/*!40000 ALTER TABLE `bidder` ENABLE KEYS */;


--
-- Definition of table `notice`
--

DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(35) DEFAULT NULL,
  `info` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` (`id`,`title`,`info`) VALUES 
 (2,'Rudratech Employee','Your are not applicable 7th oct payment.\r\nThank You!!'),
 (5,'RoadC','Pls fill it fast');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;


--
-- Definition of table `tender`
--

DROP TABLE IF EXISTS `tender`;
CREATE TABLE `tender` (
  `tid` varchar(15) NOT NULL,
  `tname` varchar(40) DEFAULT NULL,
  `ttype` varchar(20) DEFAULT NULL,
  `tprice` int(11) DEFAULT NULL,
  `tdesc` varchar(300) DEFAULT NULL,
  `tdeadline` date DEFAULT NULL,
  `tloc` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tender`
--

/*!40000 ALTER TABLE `tender` DISABLE KEYS */;
INSERT INTO `tender` (`tid`,`tname`,`ttype`,`tprice`,`tdesc`,`tdeadline`,`tloc`) VALUES 
 ('T20221007045336','Road Construction','construction',300000,'Road Construction.','2022-10-09','Pune'),
 ('T20221229032549','Abcd','maintainence',300000,'sASHGHGAS','2022-12-16','Pune'),
 ('T20221229032721','Software','software',200000,'Software Company','2022-12-15','Pune');
/*!40000 ALTER TABLE `tender` ENABLE KEYS */;


--
-- Definition of table `tenderstatus`
--

DROP TABLE IF EXISTS `tenderstatus`;
CREATE TABLE `tenderstatus` (
  `tid` varchar(15) NOT NULL,
  `bid` varchar(15) DEFAULT NULL,
  `status` varchar(15) NOT NULL,
  `vid` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenderstatus`
--

/*!40000 ALTER TABLE `tenderstatus` DISABLE KEYS */;
INSERT INTO `tenderstatus` (`tid`,`bid`,`status`,`vid`) VALUES 
 ('T20221007045336','B20221008124008','Assigned','V20221004022217'),
 ('T20221229032549','B20221229033426','Assigned','V20221229031548');
/*!40000 ALTER TABLE `tenderstatus` ENABLE KEYS */;


--
-- Definition of table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
CREATE TABLE `vendor` (
  `vid` varchar(15) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `vname` varchar(30) DEFAULT NULL,
  `vmob` varchar(12) DEFAULT NULL,
  `vemail` varchar(40) DEFAULT NULL,
  `company` varchar(15) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor`
--

/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` (`vid`,`password`,`vname`,`vmob`,`vemail`,`company`,`address`) VALUES 
 ('V20221003113600','R@123','Abc','9797979797','r@gmail.com','Rudratech','Pune'),
 ('V20221004022217','W@123','w','9595959595','w@gmail.com','Wayzon','Pune'),
 ('V20221227092035','Rusra@123','Abc','9797979797','rudra@gmail.com','Rudratech','Pune'),
 ('V20221229031430','Aaa@123','Aaa','9797979797','aaa@gmail.com','Abc','Pune'),
 ('V20221229031548','Bbb@123','Bbb','9595959595','bbb@gmail.com','Bb','Pune');
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
